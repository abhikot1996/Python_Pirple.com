

def SongName():
    string1 = "nayan ne bandh rakhine" # Song Name
    return string1

def SongTiming():
    Time = 03.31
    return Time

def RelasedYear():
    Year = 2017 # in Mont of May, Song Relased
    return Year

def add(a,b):
    if 5 == a+b:
        return True
    else:
        return False

SongName1 = SongName()
SongTiming1 = SongTiming()
SongRelasedYear = RelasedYear()
add1 = add(2,3)
print("Song Name: ",SongName1)
print("Song Timing: ",SongTiming1)
print("Song Realesed Year: ",SongRelasedYear)
print(add1)

# print("Song Name: ",SongName())
# print("Song Timing: ",SongTiming())
# print("Song Realesed Year: ",RelasedYear())