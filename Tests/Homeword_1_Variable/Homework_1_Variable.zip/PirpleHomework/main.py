"""
       Following Python code is to print favorite song's detail
       with using variable types, int, float, string and
       print() function
"""

SongName   = "nayan ne bandh rakhine" # Song Name
Singer     = "Darshan Raval" # Singer of the song
Cast       = "Darshan Raval & Zaara" # Cast of the song
SongLang   = "Gujrati and Hindi" # Song Languages
SongTiming = 03.31
Likes      = 721000 # on YouTube
RelasedOn  = "'DarshanRavalDZ' YouTube Channel" # Darshan Raval's channel
RelasedYear= 2017 # in Month of May, Song Relased year

print("Song name : ",SongName)
print("Singer Name: ",Singer)
print(" Cast: ",Cast)
print(" Song Languge: ",SongLang)
print(" Song Time: ",SongTiming)
print(" Song Likes: ",Likes)
print(" Channel which is on released song: ",RelasedOn)
print(" Year: ",RelasedYear)
